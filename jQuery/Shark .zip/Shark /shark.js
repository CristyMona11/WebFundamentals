$(document).ready(function(){

$('img').click(function(){
  $(this).hide();
});

  $('button').click(function(){
    $('img').fadeIn("slow");
  });

    });
