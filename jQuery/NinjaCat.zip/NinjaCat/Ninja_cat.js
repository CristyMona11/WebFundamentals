$(document).ready(function(){

  $('#cat0').click(function(){
  $('#ninja0').show();
  });

  $('#ninja0').click(function(){
  $('#ninja0').hide();
  });

  $('#cat1').click(function(){
  $('#ninja1').show();
  });

  $('#ninja1').click(function(){
  $('#ninja1').hide();
  });

  $('#cat2').click(function(){
  $('#ninja2').show();
  });

  $('#ninja2').click(function(){
  $('#ninja2').hide();
  });

  $('#cat3').click(function(){
  $('#ninja3').show();
  });

  $('#ninja3').click(function(){
  $('#ninja3').hide();
  });

  $('#cat4').click(function(){
  $('#ninja4').show();
  });

  $('#ninja4').click(function(){
  $('#ninja4').hide();
  });

});
