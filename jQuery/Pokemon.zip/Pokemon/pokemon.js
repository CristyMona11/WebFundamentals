$(document).ready(function(){

var poke;
  for(var i=1; i<152;i++){
    poke="<img src='http://pokeapi.co/media/img/" + i + ".png'>";
      $(".container").append(poke);
}
  // $.get("http://pokeapi.co/media/img/1.png", function(res) {
  //                  console.log(res);
  //        }, "json");

});
