
$(document).ready(function(){

  $('#snow').click(function(){
    $('#snow').hide();
  });

  $('h2').click(function(){
    $('h2').toggle(function(){

    });
  });

  $( 'h3' ).click(function() {
    $( '#clouds' ).slideDown( "fast", function() {
      // Animation complete.
    });
  });

  $( 'h1' ).click(function() {
    $( "span" ).show();
      // Animation complete.
    });

    $( 'h3' ).click(function() {
      $( '#clouds' ).slideUp( "slower", function() {
        // Animation complete.
      });
    });

});
